// Beispiel: Eine Nachricht anzeigen, wenn die Seite geladen wird
document.addEventListener("DOMContentLoaded", function() {
  alert("Willkommen auf meiner Homepage!");
});